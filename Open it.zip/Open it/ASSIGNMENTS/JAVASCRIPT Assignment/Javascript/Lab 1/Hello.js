function dispHello()
{
document.write( "<b>Hello World</b>" );
}
