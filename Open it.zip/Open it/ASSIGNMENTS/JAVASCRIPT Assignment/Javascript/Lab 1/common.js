var msg;
msg="<p><code>The actual script is in external script file called common.js</code></p>";

function addNos(headVar,bodyVar)
{

var add=parseInt(headVar)+parseInt(bodyVar);
document.write(msg);
document.write("The sum of the variables headVar and bodyVar is" +add);
}
