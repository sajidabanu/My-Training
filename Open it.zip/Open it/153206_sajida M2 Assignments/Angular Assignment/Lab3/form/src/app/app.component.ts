
import { Component, OnInit} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class Form implements OnInit {
  productform:FormGroup;
  pid:number;
  pname:string="";
  pcost:number;
  pon:string="";
  pcat:string="";
  available:string="";
  constructor( private frmBuilder : FormBuilder) { 
    this.productform = frmBuilder.group({
      pid: ['',Validators.compose([Validators.required,Validators.maxLength(6)])],
      pname: ['',[Validators.required,Validators.maxLength(20)]],
      pcost: ['',Validators.required],
      pon:['',Validators.required],
      pcat: ['',Validators.required],
      available: ['',Validators.required]
    });
  }
  ngOnInit(){
 }
onSubmit(prodForm:NgForm) {
document.getElementById('info').innerHTML ="Form Submitted";
console.log(this.productform.value);
  }

}
