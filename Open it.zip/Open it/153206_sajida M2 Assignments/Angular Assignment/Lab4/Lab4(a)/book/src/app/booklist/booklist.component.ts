import { Component, OnInit } from '@angular/core';

import { book } from './book'

import { BooklistService } from '../booklist.service'

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  booklist: book[]=[]

  constructor(private booklistService: BooklistService) { }

  ngOnInit() {
    this.getBooklist()
  }

  getBooklist() {
    this.booklistService.getBooklist().subscribe(
      (booklist:book[]) => this.booklist = booklist
      )
  }

}
