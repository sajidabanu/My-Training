export interface Iemployee {
    Id: number;
    Name:string;
    Salary:number;
    Department:string;
}