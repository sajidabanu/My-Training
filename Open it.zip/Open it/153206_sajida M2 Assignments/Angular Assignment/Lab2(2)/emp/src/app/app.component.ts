import { Component } from '@angular/core';
import {Iemployee} from './e';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  Id:number;
  Name:string;
  Salary:number;
  Department:string;
  employee:Iemployee[]=[
    {"Id":1001,"Name":"Rahul","Salary":9000,"Department":"JAVA"},
    {"Id":1002,"Name":"Vikash","Salary":11000,"Department":"ORAAPS"},
    {"Id":1003,"Name":"Uma","Salary":12000,"Department":"JAVA"},
    {"Id":1004,"Name":"Sachin","Salary":11500,"Department":"ORAAPS"},
    {"Id":1005,"Name":"Amol","Salary":7000,"Department":".NET"},
    {"Id":1006,"Name":"Vishal","Salary":17000,"Department":"BI"},
    {"Id":1007,"Name":"Rajita","Salary":21000,"Department":"BI"},
    {"Id":1008,"Name":"Neelima","Salary":81000,"Department":"TESTING"},
    {"Id":1009,"Name":"Daya","Salary":1000,"Department":"TESTING"}];
sortid(){
  this.employee.sort(function(e1, e2){
    if ( e1.Id < e2.Id )
        return -1;
    if ( e1.Id > e2.Id )
        return 1;
    return 0;
});
}
sortname(){
  this.employee.sort(function(e1, e2){
    if ( e1.Name < e2.Name )
        return -1;
    if ( e1.Name > e2.Name )
        return 1;
    return 0;
});
}
sortdepartment(){
  this.employee.sort(function(e1, e2){
    if ( e1.Department < e2.Department )
        return -1;
    if ( e1.Department > e2.Department )
        return 1;
    return 0;
});
}
sortsalary(){
  this.employee.sort(function(e1, e2){
    if ( e1.Salary < e2.Salary )
        return -1;
    if ( e1.Salary > e2.Salary )
        return 1;
    return 0;
});
}
}
