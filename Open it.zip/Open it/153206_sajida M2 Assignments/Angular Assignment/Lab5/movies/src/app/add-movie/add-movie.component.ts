import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-movie',
  templateUrl: './add-movie.component.html',
  styleUrls: ['./add-movie.component.css']
})
export class AddMovieComponent implements OnInit {
genre=['Drama','Fiction','Satire'];
pattern1="^[A-Za-z0-9_-]{1,25}$";
pattern2="^[0-9]+(.[0-9]{1,2})?$";
  ngOnInit() {
  }

}