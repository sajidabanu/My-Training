<div>
  <form #movieForm="ngForm" (ngSubmit)="submitForm(movieForm)">
    <table>
      <div class="form-group">
      <tr>
        <td>Movie Name</td>
        <td><input type="text" name="movie" id="movieId" required [pattern]="pattern1" 

[(ngModel)]="movieName" #Movie='ngModel'></td>
        <td><span *ngIf="Movie.invalid&&Movie.touched">Movie name is required</span>
        <span *ngIf="Movie.errors?.pattern">Movie Name should be only alphanumeric</span>
        </td>
      </tr>
      <tr>
        <td>Give Rating</td>
        <td><input type="number" name="rating" id="ratingId" required [pattern]="pattern2" 

[(ngModel)]="giveRating" #Rating='ngModel'></td>
        <td><span *ngIf="Rating.invalid&&Rating.touched">Rating is required</span>
        <span *ngIf="Rating.errors?.pattern">Rating is to be only number: e.g:2.5. Rating is 

on scale 1-5</span></td>
      </tr>
      <tr>
        <td>Select Genre</td>
        <td><select id="genreId" required [(ngModel)]="enterGenre" name="genre" 

#Genre="ngModel">
          <option *ngFor="let g of genre" [value]="g">{{g}}</option>
          </select></td>
          <td><span *ngIf="Genre.invalid&&Genre.touched">Select Genre!!</span></td>
      </tr>
      <tr>
        <td><input type="submit" name="add" value="Add Movie"></td>
      </tr>
      </div>
    </table>
  </form> 
  </div>