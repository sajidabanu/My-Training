export interface Iemp {
    Id: number;
    Name:string;
    Salary:number;
    Department:string;
}