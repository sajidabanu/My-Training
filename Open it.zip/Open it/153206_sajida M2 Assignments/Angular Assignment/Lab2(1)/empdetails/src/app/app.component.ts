import { Component } from '@angular/core';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {Iemp} from './emp';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 2 Operation';
  id:number;
  name:string;
  salary:number;
  department:string;
  id1:number;
  name1:string;
  salary1:number;
  department1:string;
  Update:any;
  d:any;
  employee:Iemp[]=[
    {"Id":1001,"Name":"Rahul","Salary":9000,"Department":"Java"},
    {"Id":1002,"Name":"Sachin","Salary":19000,"Department":"OraApps"},
    {"Id":1003,"Name":"Vikash","Salary":29000,"Department":"BI"}];
addemp():any
{
let e:Iemp={Id:this.id,Name:this.name,Salary:this.salary,Department:this.department};
this.employee.push(e);
}
upemp(e):any
{
  this.id1=e.Id;
  this.name1=e.Name;
  this.salary1=e.Salary;
  this.department1=e.Department;
  this.Update=e;
}
updemp():any
{
  this.Update.Id=this.id1;
  this.Update.Name=this.name1;
  this.Update.Salary=this.salary1;
  this.Update.Department=this.department1;
}
delemp(d):any
{
  this.employee.splice(d,1);
}
  }

