import { Component } from '@angular/core';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 2 Operation';
  id:number;
  ename:string;
  sal:number;
  dept:string;

addemp()
{
  alert(this.id+''+this.ename+''+this.sal+''+this.dept);
}}